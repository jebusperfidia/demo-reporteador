<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1786296215} ?>
<?php if (isset($component)) { $__componentOriginal81a506f898233b9e7d58286e6bea3c18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81a506f898233b9e7d58286e6bea3c18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::app','data' => ['title' => __('Dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dashboard'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard-stats', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2933445906-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>

    <?php ob_start(); ?><div class="[:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border border-zinc-200 dark:border-white/10 [:where(&amp;)]:p-6 [:where(&amp;)]:rounded-xl mb-6" x-data="{
        start: '',
        end: '',
        error: '',
        isLoading: false,
        init() {
            Livewire.hook('commit', ({ component, succeed }) => {
                succeed(() => {
                    if (component.name === 'payment-table') {
                        this.isLoading = false;
                    }
                })
            });
        },
        apply() {
            this.error = '';
            if (!this.start || !this.end) {
                this.error = 'Selecciona ambas fechas.';
                return;
            }
            if (this.start > this.end) {
                this.error = 'La fecha inicial no puede ser mayor a la final.';
                return;
            }
    
            this.isLoading = true;
            Livewire.dispatchTo('payment-table', 'applyDateFilter', { start: this.start, end: this.end });
        },
        clear() {
            this.start = '';
            this.end = '';
            this.error = '';
    
            this.isLoading = true;
            Livewire.dispatchTo('payment-table', 'clearDateFilter');
        }
    }" data-flux-card>
    <?php ob_start(); ?>

        <div class="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-6 gap-6">
            <div>
                <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Historial de Abonos<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?>Detalle de los pagos registrados en el sistema y progreso de cobranza.
                <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
            </div>

            <div
                class="w-full xl:w-auto flex flex-col bg-gray-50 dark:bg-zinc-800/50 p-5 sm:p-6 rounded-lg border border-gray-200 dark:border-zinc-700 shadow-sm">

                <span class="text-sm font-bold text-gray-700 dark:text-gray-300 mb-4 uppercase tracking-wider">
                    Filtrar por Rango de Fechas
                </span>

                <div class="flex flex-col sm:flex-row items-end gap-5">
                    <div class="w-full sm:w-64">
                        <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/input/index.blade.php', $__blaze->compiledPath.'/ff8fb006dfcd4cb84905d765ac5e45fd.php'); ?>
<?php $__blaze->pushData(['type' => 'date','label' => 'Desde','xModel' => 'start']); ?>
<?php _ff8fb006dfcd4cb84905d765ac5e45fd($__blaze, ['type' => 'date','label' => 'Desde','xModel' => 'start'], [], [], ['xModel' => 'x-model'], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    </div>
                    <div class="w-full sm:w-64">
                        <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/input/index.blade.php', $__blaze->compiledPath.'/ff8fb006dfcd4cb84905d765ac5e45fd.php'); ?>
<?php $__blaze->pushData(['type' => 'date','label' => 'Hasta','xModel' => 'end']); ?>
<?php _ff8fb006dfcd4cb84905d765ac5e45fd($__blaze, ['type' => 'date','label' => 'Hasta','xModel' => 'end'], [], [], ['xModel' => 'x-model'], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    </div>

                    <div class="flex items-center gap-3 w-full sm:w-auto mt-4 sm:mt-0">
                        <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-10 text-sm rounded-lg ps-4 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-s-[1px] [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)]   cursor-pointer" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" @click="apply">
        <?php ob_start(); ?>Aplicar<?php echo trim(ob_get_clean()); ?>

    </button>
<?php echo ltrim(ob_get_clean()); ?>
                        <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-10 text-sm rounded-lg ps-4 pe-4 inline-flex  bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-800 dark:text-white      cursor-pointer" data-flux-button="data-flux-button" @click="clear">
        <?php ob_start(); ?>Limpiar<?php echo trim(ob_get_clean()); ?>

    </button>
<?php echo ltrim(ob_get_clean()); ?>
                    </div>
                </div>

                <span x-show="error" x-text="error" class="text-red-500 text-sm mt-3 font-medium"
                    style="display: none;"></span>
            </div>
        </div>

        <div class="relative">
            <div x-show="isLoading" x-transition.opacity
                class="absolute inset-0 bg-white/60 dark:bg-zinc-900/60 z-10 flex items-center justify-center rounded-lg backdrop-blur-[2px]"
                style="display: none;">
                <div
                    class="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-semibold text-sm bg-white dark:bg-zinc-800 px-5 py-2.5 rounded-full shadow-md border border-gray-200 dark:border-zinc-700">
                    <svg class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none"
                        viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor"
                            stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor"
                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
                        </path>
                    </svg>
                    <span>Actualizando tabla...</span>
                </div>
            </div>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('payment-table', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2933445906-1', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
        </div>
    <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('payment-pdf-modal', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2933445906-2', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $attributes = $__attributesOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $component = $__componentOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__componentOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\reporter\resources\views/dashboard.blade.php ENDPATH**/ ?>