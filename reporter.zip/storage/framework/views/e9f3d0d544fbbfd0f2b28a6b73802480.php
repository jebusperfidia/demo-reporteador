<?php # [BlazeFolded]:{table}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/table/index.blade.php}:{1786296215} ?>
<?php ob_start(); ?><div class="flex flex-col ">
    <?php ob_start(); ?>
    <?php echo trim(ob_get_clean()); ?>


    <ui-table-scroll-area class="overflow-auto">
        <table class="[:where(&amp;)]:min-w-full table-fixed border-separate border-spacing-0 isolate text-zinc-800 whitespace-nowrap [&amp;_dialog]:whitespace-normal [&amp;_[popover]]:whitespace-normal" data-flux-table>
            <?php ob_start(); ?>
    

    

    
<?php echo trim(ob_get_clean()); ?>

        </table>
    </ui-table-scroll-area>

    <?php ob_start(); ?>
        <?php echo e($payments->links()); ?>

    <?php echo trim(ob_get_clean()); ?>


    </div>
<?php echo ltrim(ob_get_clean()); ?>
<?php /**PATH C:\laragon\www\reporter\resources\views/livewire/payment-table.blade.php ENDPATH**/ ?>