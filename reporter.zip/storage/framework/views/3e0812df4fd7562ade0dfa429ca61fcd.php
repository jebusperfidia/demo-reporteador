<?php
if (!function_exists('_3e0812df4fd7562ade0dfa429ca61fcd')):
function _3e0812df4fd7562ade0dfa429ca61fcd($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'tooltipPosition',
    'tooltipKbd',
    'tooltip',
]));
?>

<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'top',
    'tooltipKbd' => null,
    'tooltip' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
unset($__defaults);
?>

<?php if ($tooltip): ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/997dce7336dcebbe777a242294d5c895.php'); ?>
<?php if (isset($__slots997dce7336dcebbe777a242294d5c895)) { $__slotsStack997dce7336dcebbe777a242294d5c895[] = $__slots997dce7336dcebbe777a242294d5c895; } ?>
<?php if (isset($__attrs997dce7336dcebbe777a242294d5c895)) { $__attrsStack997dce7336dcebbe777a242294d5c895[] = $__attrs997dce7336dcebbe777a242294d5c895; } ?>
<?php $__attrs997dce7336dcebbe777a242294d5c895 = ['content' => $tooltip,'position' => $tooltipPosition,'kbd' => $tooltipKbd]; ?>
<?php $__slots997dce7336dcebbe777a242294d5c895 = []; ?>
<?php $__blaze->pushData($__attrs997dce7336dcebbe777a242294d5c895); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>

    <?php $__slots997dce7336dcebbe777a242294d5c895['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots997dce7336dcebbe777a242294d5c895); ?>
<?php _997dce7336dcebbe777a242294d5c895($__blaze, $__attrs997dce7336dcebbe777a242294d5c895, $__slots997dce7336dcebbe777a242294d5c895, ['content', 'position', 'kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack997dce7336dcebbe777a242294d5c895)) { $__slots997dce7336dcebbe777a242294d5c895 = array_pop($__slotsStack997dce7336dcebbe777a242294d5c895); } ?>
<?php if (! empty($__attrsStack997dce7336dcebbe777a242294d5c895)) { $__attrs997dce7336dcebbe777a242294d5c895 = array_pop($__attrsStack997dce7336dcebbe777a242294d5c895); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/with-tooltip.blade.php ENDPATH**/ ?>