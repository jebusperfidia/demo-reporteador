<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::select}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/select/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1786296215} ?>
<div>
    <!-- Encabezado con Selector Dinámico -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
            <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-2xl [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Resumen Financiero<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?>Indicadores basados en el rango seleccionado.<?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        </div>

        <div class="w-full sm:w-56">
            <?php ob_start(); ?><select
    class="appearance-none [:where(&amp;)]:w-full ps-3 pe-10 block h-10 py-2 text-base sm:text-sm leading-[1.375rem] rounded-lg shadow-xs border bg-white dark:bg-white/10 dark:disabled:bg-white/[7%] text-zinc-700 dark:text-zinc-300 disabled:text-zinc-500 dark:disabled:text-zinc-400 has-[option.placeholder:checked]:text-zinc-400 dark:has-[option.placeholder:checked]:text-zinc-400 dark:[&amp;_option]:bg-zinc-700 dark:[&amp;_option]:text-white disabled:shadow-none border border-zinc-200 border-b-zinc-300/80 dark:border-white/10" wire:model.live="monthsToShow"
         name="monthsToShow"         data-flux-control
    data-flux-select-native
    data-flux-group-target
>
    
    <?php ob_start(); ?>
                <option value="3">Últimos 3 meses</option>
                <option value="6">Últimos 6 meses</option>
                <option value="12">Último año</option>
            <?php echo trim(ob_get_clean()); ?>

</select>
<?php echo ltrim(ob_get_clean()); ?>
        </div>
    </div>

    <!-- Fila de Tarjetas (KPIs). Se actualizan solas gracias a Livewire -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <?php ob_start(); ?><div class="[:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border border-zinc-200 dark:border-white/10 [:where(&amp;)]:p-6 [:where(&amp;)]:rounded-xl" data-flux-card>
    <?php ob_start(); ?>
            <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Nuevos Clientes<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 text-3xl font-bold mt-2" data-flux-subheading>
    <?php ob_start(); ?>
                <?php echo e($totalCustomers); ?>

            <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>

        <?php ob_start(); ?><div class="[:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border border-zinc-200 dark:border-white/10 [:where(&amp;)]:p-6 [:where(&amp;)]:rounded-xl" data-flux-card>
    <?php ob_start(); ?>
            <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Ventas en el Periodo<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 text-3xl font-bold text-blue-600 dark:text-blue-400 mt-2" data-flux-subheading>
    <?php ob_start(); ?>
                $<?php echo e(number_format($totalSales, 2)); ?>

            <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>

        <?php ob_start(); ?><div class="[:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border border-zinc-200 dark:border-white/10 [:where(&amp;)]:p-6 [:where(&amp;)]:rounded-xl" data-flux-card>
    <?php ob_start(); ?>
            <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Total Cobrado<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 text-3xl font-bold text-green-600 dark:text-green-400 mt-2" data-flux-subheading>
    <?php ob_start(); ?>
                $<?php echo e(number_format($totalPaid, 2)); ?>

            <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>

        <?php ob_start(); ?><div class="[:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border border-zinc-200 dark:border-white/10 [:where(&amp;)]:p-6 [:where(&amp;)]:rounded-xl" data-flux-card>
    <?php ob_start(); ?>
            <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Cartera Vencida<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 text-3xl font-bold text-red-600 dark:text-red-400 mt-2" data-flux-subheading>
    <?php ob_start(); ?>
                $<?php echo e(number_format($pendingBalance, 2)); ?>

            <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
    </div>

    <!-- Contenedor de la Gráfica -->
    <?php ob_start(); ?><div class="[:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border border-zinc-200 dark:border-white/10 [:where(&amp;)]:p-6 [:where(&amp;)]:rounded-xl mb-6" data-flux-card>
    <?php ob_start(); ?>
        <div class="mb-4">
            <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Comparativo de Ingresos vs Ventas<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
        </div>

        <!-- Escudo wire:ignore y limpieza de RAM con destroy() -->
        <div wire:ignore class="w-full h-80" x-data="{
            chartInstance: null,
            init() {
                // Cargamos la gráfica inicial
                this.drawChart(<?php echo e(json_encode($chartData)); ?>);
            },
            drawChart(dataObj) {
                // 1. LA MAGIA ANTI-LAG: Si ya hay una gráfica, mátala para liberar RAM
                if (this.chartInstance) {
                    this.chartInstance.destroy();
                }
        
                // 2. Dibuja la nueva gráfica limpia
                let ctx = this.$refs.canvas.getContext('2d');
                this.chartInstance = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: dataObj.labels,
                        datasets: [{
                                label: 'Total de Ventas',
                                data: dataObj.sales,
                                backgroundColor: '#3b82f6',
                                borderRadius: 4
                            },
                            {
                                label: 'Abonos Recibidos',
                                data: dataObj.payments,
                                backgroundColor: '#22c55e',
                                borderRadius: 4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { position: 'bottom' } },
                        scales: { y: { beginAtZero: true } }
                    }
                });
            }
        }" @update-chart.window="drawChart($event.detail)">
            <canvas x-ref="canvas"></canvas>
        </div>
    <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
</div>
<?php /**PATH C:\laragon\www\reporter\resources\views/livewire/dashboard-stats.blade.php ENDPATH**/ ?>