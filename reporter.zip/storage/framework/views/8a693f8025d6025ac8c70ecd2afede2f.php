<svg
    <?php echo e($attributes->merge(['class' => 'pointer-events-none'])); ?>

    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
>
    <path
        stroke-linecap="round"
        stroke-linejoin="round"
        stroke-width="2"
        d="M19 9l-7 7-7-7"
    />
</svg>
<?php /**PATH C:\laragon\www\reporter\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/icons/down.blade.php ENDPATH**/ ?>