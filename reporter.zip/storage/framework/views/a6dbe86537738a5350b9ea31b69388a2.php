<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'sidebar' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'sidebar' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sidebar): ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/brand.blade.php', $__blaze->compiledPath.'/6880c7e5d03b64d4c17eb5f0bb0794de.php'); ?>
<?php if (isset($__slots6880c7e5d03b64d4c17eb5f0bb0794de)) { $__slotsStack6880c7e5d03b64d4c17eb5f0bb0794de[] = $__slots6880c7e5d03b64d4c17eb5f0bb0794de; } ?>
<?php if (isset($__attrs6880c7e5d03b64d4c17eb5f0bb0794de)) { $__attrsStack6880c7e5d03b64d4c17eb5f0bb0794de[] = $__attrs6880c7e5d03b64d4c17eb5f0bb0794de; } ?>
<?php $__attrs6880c7e5d03b64d4c17eb5f0bb0794de = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slots6880c7e5d03b64d4c17eb5f0bb0794de = []; ?>
<?php $__blaze->pushData($__attrs6880c7e5d03b64d4c17eb5f0bb0794de); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slots6880c7e5d03b64d4c17eb5f0bb0794de['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground']); ?>
    <?php $__slots6880c7e5d03b64d4c17eb5f0bb0794de['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots6880c7e5d03b64d4c17eb5f0bb0794de); ?>
<?php _6880c7e5d03b64d4c17eb5f0bb0794de($__blaze, $__attrs6880c7e5d03b64d4c17eb5f0bb0794de, $__slots6880c7e5d03b64d4c17eb5f0bb0794de, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack6880c7e5d03b64d4c17eb5f0bb0794de)) { $__slots6880c7e5d03b64d4c17eb5f0bb0794de = array_pop($__slotsStack6880c7e5d03b64d4c17eb5f0bb0794de); } ?>
<?php if (! empty($__attrsStack6880c7e5d03b64d4c17eb5f0bb0794de)) { $__attrs6880c7e5d03b64d4c17eb5f0bb0794de = array_pop($__attrsStack6880c7e5d03b64d4c17eb5f0bb0794de); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/brand.blade.php', $__blaze->compiledPath.'/944e7226d756aced52bc84fbc273e1ae.php'); ?>
<?php if (isset($__slots944e7226d756aced52bc84fbc273e1ae)) { $__slotsStack944e7226d756aced52bc84fbc273e1ae[] = $__slots944e7226d756aced52bc84fbc273e1ae; } ?>
<?php if (isset($__attrs944e7226d756aced52bc84fbc273e1ae)) { $__attrsStack944e7226d756aced52bc84fbc273e1ae[] = $__attrs944e7226d756aced52bc84fbc273e1ae; } ?>
<?php $__attrs944e7226d756aced52bc84fbc273e1ae = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slots944e7226d756aced52bc84fbc273e1ae = []; ?>
<?php $__blaze->pushData($__attrs944e7226d756aced52bc84fbc273e1ae); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slots944e7226d756aced52bc84fbc273e1ae['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground']); ?>
    <?php $__slots944e7226d756aced52bc84fbc273e1ae['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots944e7226d756aced52bc84fbc273e1ae); ?>
<?php _944e7226d756aced52bc84fbc273e1ae($__blaze, $__attrs944e7226d756aced52bc84fbc273e1ae, $__slots944e7226d756aced52bc84fbc273e1ae, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack944e7226d756aced52bc84fbc273e1ae)) { $__slots944e7226d756aced52bc84fbc273e1ae = array_pop($__slotsStack944e7226d756aced52bc84fbc273e1ae); } ?>
<?php if (! empty($__attrsStack944e7226d756aced52bc84fbc273e1ae)) { $__attrs944e7226d756aced52bc84fbc273e1ae = array_pop($__attrsStack944e7226d756aced52bc84fbc273e1ae); } ?>
<?php $__blaze->popData(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\laragon\www\reporter\resources\views/components/app-logo.blade.php ENDPATH**/ ?>