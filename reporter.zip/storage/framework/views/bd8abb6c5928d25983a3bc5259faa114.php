<tr
    class="<?php echo e(theme_style($theme, 'table.header.tr')); ?>"
>
    <th
        class="<?php echo e(theme_style($theme, 'table.body.tdEmpty')); ?>"
        colspan="999"
    >
        <?php echo $this->processNoDataLabel; ?>

    </th>
</tr>
<?php /**PATH C:\laragon\www\reporter\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/table/th-empty.blade.php ENDPATH**/ ?>