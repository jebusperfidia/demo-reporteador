<?php
if (!function_exists('__0e46184bcb34878a32aa4d93bdb7b174')):
function __0e46184bcb34878a32aa4d93bdb7b174($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'name',
    'descriptionTrailing',
    'description',
    'label',
    'badge',
]));
?>

<?php $descriptionTrailing = $descriptionTrailing ??= $attributes->pluck('description:trailing'); ?>

<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
    'descriptionTrailing' => null,
    'description' => null,
    'label' => null,
    'badge' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$descriptionTrailing ??= $attributes['description-trailing'] ?? $attributes['descriptionTrailing'] ?? $__defaults['descriptionTrailing']; unset($attributes['descriptionTrailing'], $attributes['description-trailing']);
$description ??= $attributes['description'] ?? $__defaults['description']; unset($attributes['description']);
$label ??= $attributes['label'] ?? $__defaults['label']; unset($attributes['label']);
$badge ??= $attributes['badge'] ?? $__defaults['badge']; unset($attributes['badge']);
unset($__defaults);
?>

<?php if (isset($label) || isset($description) || isset($descriptionTrailing)): ?>
    <?php

        $fieldAttributes = Flux::attributesAfter('field:', $attributes, []);
        $labelAttributes = Flux::attributesAfter('label:', $attributes, ['badge' => $badge]);
        $descriptionAttributes = Flux::attributesAfter('description:', $attributes, []);
        $errorAttributes = Flux::attributesAfter('error:', $attributes, ['name' => $name]);
    ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php', $__blaze->compiledPath.'/ecaade68172648b8d1c1c03f3f6cbec2.php'); ?>
<?php if (isset($__slotsecaade68172648b8d1c1c03f3f6cbec2)) { $__slotsStackecaade68172648b8d1c1c03f3f6cbec2[] = $__slotsecaade68172648b8d1c1c03f3f6cbec2; } ?>
<?php if (isset($__attrsecaade68172648b8d1c1c03f3f6cbec2)) { $__attrsStackecaade68172648b8d1c1c03f3f6cbec2[] = $__attrsecaade68172648b8d1c1c03f3f6cbec2; } ?>
<?php $__attrsecaade68172648b8d1c1c03f3f6cbec2 = ['attributes' => $fieldAttributes]; ?>
<?php $__slotsecaade68172648b8d1c1c03f3f6cbec2 = []; ?>
<?php $__blaze->pushData($__attrsecaade68172648b8d1c1c03f3f6cbec2); ?>
<?php ob_start(); ?>
        <?php if (isset($label)): ?>
            <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php', $__blaze->compiledPath.'/6625dfb05e96a1201ff7bbf8086735de.php'); ?>
<?php if (isset($__slots6625dfb05e96a1201ff7bbf8086735de)) { $__slotsStack6625dfb05e96a1201ff7bbf8086735de[] = $__slots6625dfb05e96a1201ff7bbf8086735de; } ?>
<?php if (isset($__attrs6625dfb05e96a1201ff7bbf8086735de)) { $__attrsStack6625dfb05e96a1201ff7bbf8086735de[] = $__attrs6625dfb05e96a1201ff7bbf8086735de; } ?>
<?php $__attrs6625dfb05e96a1201ff7bbf8086735de = ['attributes' => $labelAttributes]; ?>
<?php $__slots6625dfb05e96a1201ff7bbf8086735de = []; ?>
<?php $__blaze->pushData($__attrs6625dfb05e96a1201ff7bbf8086735de); ?>
<?php ob_start(); ?><?php echo e($label); ?><?php $__slots6625dfb05e96a1201ff7bbf8086735de['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots6625dfb05e96a1201ff7bbf8086735de); ?>
<?php __6625dfb05e96a1201ff7bbf8086735de($__blaze, $__attrs6625dfb05e96a1201ff7bbf8086735de, $__slots6625dfb05e96a1201ff7bbf8086735de, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack6625dfb05e96a1201ff7bbf8086735de)) { $__slots6625dfb05e96a1201ff7bbf8086735de = array_pop($__slotsStack6625dfb05e96a1201ff7bbf8086735de); } ?>
<?php if (! empty($__attrsStack6625dfb05e96a1201ff7bbf8086735de)) { $__attrs6625dfb05e96a1201ff7bbf8086735de = array_pop($__attrsStack6625dfb05e96a1201ff7bbf8086735de); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php if (isset($description)): ?>
            <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/31ce559e3ad718375fdb265888d9b551.php'); ?>
<?php if (isset($__slots31ce559e3ad718375fdb265888d9b551)) { $__slotsStack31ce559e3ad718375fdb265888d9b551[] = $__slots31ce559e3ad718375fdb265888d9b551; } ?>
<?php if (isset($__attrs31ce559e3ad718375fdb265888d9b551)) { $__attrsStack31ce559e3ad718375fdb265888d9b551[] = $__attrs31ce559e3ad718375fdb265888d9b551; } ?>
<?php $__attrs31ce559e3ad718375fdb265888d9b551 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots31ce559e3ad718375fdb265888d9b551 = []; ?>
<?php $__blaze->pushData($__attrs31ce559e3ad718375fdb265888d9b551); ?>
<?php ob_start(); ?><?php echo e($description); ?><?php $__slots31ce559e3ad718375fdb265888d9b551['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots31ce559e3ad718375fdb265888d9b551); ?>
<?php __31ce559e3ad718375fdb265888d9b551($__blaze, $__attrs31ce559e3ad718375fdb265888d9b551, $__slots31ce559e3ad718375fdb265888d9b551, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack31ce559e3ad718375fdb265888d9b551)) { $__slots31ce559e3ad718375fdb265888d9b551 = array_pop($__slotsStack31ce559e3ad718375fdb265888d9b551); } ?>
<?php if (! empty($__attrsStack31ce559e3ad718375fdb265888d9b551)) { $__attrs31ce559e3ad718375fdb265888d9b551 = array_pop($__attrsStack31ce559e3ad718375fdb265888d9b551); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php echo e($slot); ?>


        
        [STARTCOMPILEDUNBLAZE:jQsIIfihIf]<?php \Livewire\Blaze\Unblaze::storeScope("jQsIIfihIf", scope: ['attributes' => $errorAttributes->getAttributes()]) ?>[ENDCOMPILEDUNBLAZE:jQsIIfihIf]

        <?php if (isset($descriptionTrailing)): ?>
            <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/31ce559e3ad718375fdb265888d9b551.php'); ?>
<?php if (isset($__slots31ce559e3ad718375fdb265888d9b551)) { $__slotsStack31ce559e3ad718375fdb265888d9b551[] = $__slots31ce559e3ad718375fdb265888d9b551; } ?>
<?php if (isset($__attrs31ce559e3ad718375fdb265888d9b551)) { $__attrsStack31ce559e3ad718375fdb265888d9b551[] = $__attrs31ce559e3ad718375fdb265888d9b551; } ?>
<?php $__attrs31ce559e3ad718375fdb265888d9b551 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots31ce559e3ad718375fdb265888d9b551 = []; ?>
<?php $__blaze->pushData($__attrs31ce559e3ad718375fdb265888d9b551); ?>
<?php ob_start(); ?><?php echo e($descriptionTrailing); ?><?php $__slots31ce559e3ad718375fdb265888d9b551['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots31ce559e3ad718375fdb265888d9b551); ?>
<?php __31ce559e3ad718375fdb265888d9b551($__blaze, $__attrs31ce559e3ad718375fdb265888d9b551, $__slots31ce559e3ad718375fdb265888d9b551, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack31ce559e3ad718375fdb265888d9b551)) { $__slots31ce559e3ad718375fdb265888d9b551 = array_pop($__slotsStack31ce559e3ad718375fdb265888d9b551); } ?>
<?php if (! empty($__attrsStack31ce559e3ad718375fdb265888d9b551)) { $__attrs31ce559e3ad718375fdb265888d9b551 = array_pop($__attrsStack31ce559e3ad718375fdb265888d9b551); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    <?php $__slotsecaade68172648b8d1c1c03f3f6cbec2['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsecaade68172648b8d1c1c03f3f6cbec2); ?>
<?php __ecaade68172648b8d1c1c03f3f6cbec2($__blaze, $__attrsecaade68172648b8d1c1c03f3f6cbec2, $__slotsecaade68172648b8d1c1c03f3f6cbec2, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackecaade68172648b8d1c1c03f3f6cbec2)) { $__slotsecaade68172648b8d1c1c03f3f6cbec2 = array_pop($__slotsStackecaade68172648b8d1c1c03f3f6cbec2); } ?>
<?php if (! empty($__attrsStackecaade68172648b8d1c1c03f3f6cbec2)) { $__attrsecaade68172648b8d1c1c03f3f6cbec2 = array_pop($__attrsStackecaade68172648b8d1c1c03f3f6cbec2); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php ENDPATH**/ ?>