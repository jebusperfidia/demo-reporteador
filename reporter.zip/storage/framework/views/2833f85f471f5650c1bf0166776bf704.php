<?php
if (!function_exists('_2833f85f471f5650c1bf0166776bf704')):
function _2833f85f471f5650c1bf0166776bf704($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'iconVariant' => 'mini',
    'size' => null,
];
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$size ??= $attributes['size'] ?? $__defaults['size']; unset($attributes['size']);
unset($__defaults);
?>

<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1',
    'square' => true,
    'size' => null,
]);
?>

<?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/21b5bd8a9df6653fd5bed7197f33b1a6.php'); ?>
<?php if (isset($__slots21b5bd8a9df6653fd5bed7197f33b1a6)) { $__slotsStack21b5bd8a9df6653fd5bed7197f33b1a6[] = $__slots21b5bd8a9df6653fd5bed7197f33b1a6; } ?>
<?php if (isset($__attrs21b5bd8a9df6653fd5bed7197f33b1a6)) { $__attrsStack21b5bd8a9df6653fd5bed7197f33b1a6[] = $__attrs21b5bd8a9df6653fd5bed7197f33b1a6; } ?>
<?php $__attrs21b5bd8a9df6653fd5bed7197f33b1a6 = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm','xData' => 'fluxInputViewable','xOn:click' => 'toggle()','xBind:dataViewableOpen' => 'open','ariaLabel' => e(__('Toggle password visibility'))]; ?>
<?php $__slots21b5bd8a9df6653fd5bed7197f33b1a6 = []; ?>
<?php $__blaze->pushData($__attrs21b5bd8a9df6653fd5bed7197f33b1a6); ?>
<?php ob_start(); ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye-slash.blade.php', $__blaze->compiledPath.'/4c36ad562542ead2f360905c30ed1671.php'); ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block']); ?>
<?php _4c36ad562542ead2f360905c30ed1671($__blaze, ['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye.blade.php', $__blaze->compiledPath.'/cad6c980ab2bd460d7e2be9272c9d846.php'); ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden']); ?>
<?php _cad6c980ab2bd460d7e2be9272c9d846($__blaze, ['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
<?php $__slots21b5bd8a9df6653fd5bed7197f33b1a6['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots21b5bd8a9df6653fd5bed7197f33b1a6); ?>
<?php _21b5bd8a9df6653fd5bed7197f33b1a6($__blaze, $__attrs21b5bd8a9df6653fd5bed7197f33b1a6, $__slots21b5bd8a9df6653fd5bed7197f33b1a6, ['attributes', 'size'], ['xData' => 'x-data', 'xOn:click' => 'x-on:click', 'xBind:dataViewableOpen' => 'x-bind:data-viewable-open', 'ariaLabel' => 'aria-label'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack21b5bd8a9df6653fd5bed7197f33b1a6)) { $__slots21b5bd8a9df6653fd5bed7197f33b1a6 = array_pop($__slotsStack21b5bd8a9df6653fd5bed7197f33b1a6); } ?>
<?php if (! empty($__attrsStack21b5bd8a9df6653fd5bed7197f33b1a6)) { $__attrs21b5bd8a9df6653fd5bed7197f33b1a6 = array_pop($__attrsStack21b5bd8a9df6653fd5bed7197f33b1a6); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH C:\laragon\www\reporter\vendor\livewire\flux\src/../stubs/resources/views/flux/input/viewable.blade.php ENDPATH**/ ?>